/* ================================================================
   ANKOAUTCA — CORE.JS
   Theme · Auth · Toast · Supabase · Navbar · Utils
   ================================================================ */

/* ── Supabase Config ── */
// → Config in supabase-config.js


const SB = {
  h: { 'Content-Type':'application/json', 'apikey': SUPA_KEY, 'Authorization': `Bearer ${SUPA_KEY}` },
  async get(table, qs='') {
    try {
      const r = await fetch(`${SUPA_URL}/rest/v1/${table}?${qs}`, { headers: this.h });
      if (!r.ok) throw new Error(r.status);
      return await r.json();
    } catch { return null; }
  },
  async post(table, body) {
    try {
      const r = await fetch(`${SUPA_URL}/rest/v1/${table}`, {
        method:'POST', headers:{...this.h,'Prefer':'return=representation'}, body:JSON.stringify(body)
      });
      if (!r.ok) throw new Error(r.status);
      return await r.json();
    } catch { return null; }
  },
  async patch(table, filter, body) {
    try {
      const r = await fetch(`${SUPA_URL}/rest/v1/${table}?${filter}`, {
        method:'PATCH', headers:{...this.h,'Prefer':'return=representation'}, body:JSON.stringify(body)
      });
      return r.ok;
    } catch { return false; }
  },
  async del(table, filter) {
    try {
      const r = await fetch(`${SUPA_URL}/rest/v1/${table}?${filter}`, { method:'DELETE', headers:this.h });
      return r.ok;
    } catch { return false; }
  }
};

/* ── Static fallback articles ── */
const STATIC_NEWS = [
  {id:1,category:'politica',title:"Il Parlamento approva la riforma costituzionale con 318 voti a favore",excerpt:"Una storica riforma che cambia il volto dello Stato italiano dopo decenni di dibattiti parlamentari e consultazioni popolari.",author:"Giulia Marchetti",created_at:"2025-05-13T08:00:00Z",views:48230,reading_time:4,featured:true,hue:220,tags:["governo","riforma","parlamento"]},
  {id:2,category:'economia',title:"Borsa di Milano ai massimi: FTSE MIB sfonda quota 40.000 punti",excerpt:"La corsa dei mercati europei trainata dal settore energetico e bancario. Gli analisti restano ottimisti.",author:"Marco Ferretti",created_at:"2025-05-13T09:15:00Z",views:31450,reading_time:3,featured:true,hue:140,tags:["borsa","mercati","economia"]},
  {id:3,category:'sport',title:"Azzurri ai Mondiali 2026: l'Italia batte la Grecia 3-0 con una prestazione dominante",excerpt:"Doppietta di Scamacca e rete di Barella regalano la qualificazione con due turni di anticipo.",author:"Roberto Conti",created_at:"2025-05-13T10:00:00Z",views:44200,reading_time:2,featured:true,hue:30,tags:["calcio","mondiale","nazionale"]},
  {id:4,category:'tecnologia',title:"OpenAI lancia GPT-5: ragionamento a livello umano nelle scienze",excerpt:"Il nuovo modello supera i benchmark in matematica, codice e ragionamento complesso. Disponibile gratis.",author:"Elena Russo",created_at:"2025-05-13T11:00:00Z",views:19800,reading_time:5,featured:false,hue:270,tags:["AI","OpenAI","tech"]},
  {id:5,category:'salute',title:"Alzheimer: scoperto biomarcatore che anticipa la diagnosi di 10 anni",excerpt:"Ricercatori italiani protagonisti di una svolta pubblicata su Nature Medicine. Un passo cruciale.",author:"Federica Rizzo",created_at:"2025-05-12T14:00:00Z",views:17200,reading_time:4,featured:false,hue:330,tags:["alzheimer","salute","ricerca"]},
  {id:6,category:'mondo',title:"Gaza: accordo di tregua per 45 giorni mediato da Qatar e USA",excerpt:"Dopo settimane di negoziati le parti raggiungono un'intesa con scambi di ostaggi e corridoi umanitari.",author:"Andrea Lombardo",created_at:"2025-05-12T16:00:00Z",views:38900,reading_time:5,featured:false,hue:50,tags:["gaza","guerra","diplomazia"]},
  {id:7,category:'ambiente',title:"Siccità record in Sicilia: governo dichiara lo stato di emergenza idrica",excerpt:"Le riserve idriche dell'isola sono al minimo storico. Misure straordinarie per 2 milioni di cittadini.",author:"Luca Esposito",created_at:"2025-05-12T18:00:00Z",views:14500,reading_time:3,featured:false,hue:160,tags:["siccità","sicilia","ambiente"]},
  {id:8,category:'cultura',title:"Paolo Sorrentino vince la Palma d'Oro a Cannes con 'La Grazia'",excerpt:"Il regista napoletano torna al vertice del cinema mondiale con un'opera personale e commovente.",author:"Valentina Serra",created_at:"2025-05-11T20:00:00Z",views:9700,reading_time:3,featured:false,hue:300,tags:["cinema","cannes","sorrentino"]},
  {id:9,category:'scienze',title:"Rover ESA atterra con successo sul Polo Sud della Luna: missione storica",excerpt:"La prima missione lunare europea tocca suolo selenico dopo sei anni di intensa preparazione.",author:"Chiara Fontana",created_at:"2025-05-11T12:00:00Z",views:21400,reading_time:4,featured:false,hue:190,tags:["luna","ESA","spazio"]},
  {id:10,category:'economia',title:"FIAT annuncia 5.000 nuove assunzioni in Italia: investimento da 3 miliardi",excerpt:"Il piano industriale 2025-2030 punta sui veicoli elettrici e l'automazione avanzata degli stabilimenti.",author:"Paolo Gentili",created_at:"2025-05-11T09:00:00Z",views:12300,reading_time:3,featured:false,hue:100,tags:["FIAT","lavoro","auto"]},
  {id:11,category:'politica',title:"Crisi di governo: il Premier annuncia le dimissioni al Quirinale",excerpt:"Dopo la rottura con il principale alleato di coalizione, il Presidente rimette il mandato.",author:"Marco Ferretti",created_at:"2025-05-10T17:00:00Z",views:55600,reading_time:5,featured:false,hue:210,tags:["governo","crisi","premier"]},
  {id:12,category:'sport',title:"Formula 1 Monaco: Leclerc vince il GP di casa davanti ai tifosi",excerpt:"Il pilota monegasco della Ferrari porta a casa la vittoria più emozionante della sua carriera.",author:"Roberto Conti",created_at:"2025-05-10T15:00:00Z",views:44200,reading_time:3,featured:false,hue:40,tags:["F1","ferrari","monaco"]},
];

const STATIC_BLOGS = [
  {id:1,title:"Perché l'Italia deve investire di più nella ricerca scientifica",excerpt:"Un'analisi approfondita del gap tra investimenti pubblici italiani ed europei nella ricerca e sviluppo tecnologico.",author:"Prof. Alberto Mancini",avatar:"AM",created_at:"2025-05-12T10:00:00Z",views:8400,read_time:6,tags:["ricerca","università","politica"],hue:200},
  {id:2,title:"Il futuro del giornalismo nell'era dell'intelligenza artificiale",excerpt:"Come l'IA sta trasformando la produzione e il consumo delle notizie. Sfide, opportunità e rischi concreti.",author:"Elena Russo",avatar:"ER",created_at:"2025-05-11T14:00:00Z",views:6700,read_time:5,tags:["AI","giornalismo","media"],hue:260},
  {id:3,title:"La cucina italiana nel mondo: un'eccellenza da proteggere e valorizzare",excerpt:"Dal pesto alla carbonara: il soft power della gastronomia italiana tra tutele IGP e imitazioni globali.",author:"Valentina Serra",avatar:"VS",created_at:"2025-05-10T11:00:00Z",views:5200,read_time:4,tags:["cucina","cultura","turismo"],hue:20},
  {id:4,title:"Giovani e politica: l'astensionismo è un segnale d'allarme che non possiamo ignorare",excerpt:"L'analisi del calo della partecipazione elettorale tra i 18-35 anni e le possibili soluzioni strutturali.",author:"Dott.ssa Carla Benedetti",avatar:"CB",created_at:"2025-05-09T09:00:00Z",views:4800,read_time:7,tags:["giovani","politica","democrazia"],hue:240},
  {id:5,title:"Smart working nel 2025: dove siamo arrivati davvero dopo cinque anni",excerpt:"Un bilancio a cinque anni dalla pandemia. Chi lavora da casa, con quali risultati e a quale costo.",author:"Paolo Gentili",avatar:"PG",created_at:"2025-05-08T16:00:00Z",views:7100,read_time:5,tags:["lavoro","smart working","economia"],hue:130},
  {id:6,title:"Il Mediterraneo come frontiera: immigrazione e geopolitica nel 2025",excerpt:"Un'analisi delle rotte migratorie e delle politiche europee. Dati, tendenze e prospettive per il futuro.",author:"Andrea Lombardo",avatar:"AL",created_at:"2025-05-07T08:00:00Z",views:9300,read_time:8,tags:["immigrazione","mediterraneo","EU"],hue:180},
];

/* ── Theme ── */
const Theme = {
  K: 'anko_theme',
  get()  { return localStorage.getItem(this.K) || 'light'; },
  set(t) { localStorage.setItem(this.K, t); document.documentElement.setAttribute('data-theme', t); this._icon(); },
  toggle(){ this.set(this.get() === 'dark' ? 'light' : 'dark'); },
  init()  { this.set(this.get()); },
  _icon() {
    const t = this.get();
    document.querySelectorAll('[data-ti]').forEach(el => el.textContent = t==='dark' ? '☀️' : '🌙');
    document.querySelectorAll('.theme-toggle').forEach(el => {});
  }
};

/* ── Auth ── */
const Auth = {
  K: 'anko_sess',
  getSession() { try { return JSON.parse(localStorage.getItem(this.K)); } catch { return null; } },
  setSession(d) { localStorage.setItem(this.K, JSON.stringify({...d, ts: Date.now()})); },
  clear()      { localStorage.removeItem(this.K); },
  isLoggedIn() { const s=this.getSession(); return s && (Date.now()-s.ts)<86400000; },
  login(u, p)  {
    if ((u==='admin'||u==='redazione') && (p==='admin2024'||p==='ankoautca')) {
      this.setSession({username:u, name:'Amministratore', role:'admin'});
      return true;
    }
    return false;
  },
  logout() {
    this.clear();
    Toast.show('Disconnesso','Arrivederci!','info');
    setTimeout(() => location.href = getRoot()+'index.html', 900);
  },
  require() {
    if (!this.isLoggedIn()) {
      location.href = getRoot()+'pages/login.html?r='+encodeURIComponent(location.pathname);
      return false;
    }
    return true;
  }
};

/* ── Toast ── */
const Toast = {
  init() {
    if (!document.getElementById('toast-wrap')) {
      const d = document.createElement('div');
      d.id = 'toast-wrap';
      document.body.appendChild(d);
    }
  },
  show(title, msg='', type='info', dur=4200) {
    this.init();
    const icons = {success:'✓',error:'✕',info:'ℹ',warning:'⚠'};
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.innerHTML = `<span class="toast-ic">${icons[type]||'ℹ'}</span>
      <div class="toast-body"><div class="toast-title">${title}</div>${msg?`<div class="toast-msg">${msg}</div>`:''}</div>
      <button class="toast-x" onclick="this.parentElement.remove()">×</button>`;
    document.getElementById('toast-wrap').appendChild(el);
    setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 280); }, dur);
  }
};

/* ── Scroll Reveal ── */
const Reveal = {
  init() {
    const obs = new IntersectionObserver(entries => {
      entries.forEach(e => { if(e.isIntersecting){e.target.classList.add('in');obs.unobserve(e.target);} });
    }, {threshold:.08,rootMargin:'0px 0px -36px 0px'});
    document.querySelectorAll('.reveal').forEach(el => obs.observe(el));
  }
};

/* ── Navbar ── */
const Nav = {
  init() {
    // hamburger
    const ham = document.querySelector('.hamburger');
    const mob = document.querySelector('.mobile-nav');
    if (ham && mob) {
      ham.addEventListener('click', () => {
        ham.classList.toggle('open');
        mob.classList.toggle('open');
      });
      // close on link click
      mob.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
        ham.classList.remove('open'); mob.classList.remove('open');
      }));
    }
    // scroll shadow
    window.addEventListener('scroll', () => {
      document.querySelector('.navbar')?.classList.toggle('scrolled', window.scrollY > 8);
    }, {passive:true});
    // active link
    document.querySelectorAll('.nav-link, .mob-link').forEach(a => {
      if (a.href && (a.href === location.href || a.href.split('?')[0] === location.href.split('?')[0])) a.classList.add('on');
    });
    // theme
    document.querySelectorAll('[data-theme-btn]').forEach(btn => {
      btn.addEventListener('click', () => { Theme.toggle(); });
    });
    // auth state
    this.updateAuth();
  },
  updateAuth() {
    const logged = Auth.isLoggedIn();
    document.querySelectorAll('[data-auth-show]').forEach(el => el.style.display = logged ? '' : 'none');
    document.querySelectorAll('[data-auth-hide]').forEach(el => el.style.display = logged ? 'none' : '');
    const s = Auth.getSession();
    if (s) document.querySelectorAll('[data-user-name]').forEach(el => el.textContent = s.name || s.username);
  }
};

/* ── Helpers ── */
function getRoot() {
  return location.pathname.includes('/pages/') ? '../' : './';
}
function timeAgo(dateStr) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const m = Math.floor(diff/60000);
  if (m < 1)  return 'Adesso';
  if (m < 60) return `${m} min fa`;
  const h = Math.floor(m/60);
  if (h < 24) return `${h}h fa`;
  const d = Math.floor(h/24);
  if (d < 7)  return `${d}gg fa`;
  return new Intl.DateTimeFormat('it-IT',{day:'numeric',month:'short'}).format(new Date(dateStr));
}
function fNum(n) { return new Intl.NumberFormat('it-IT').format(n||0); }
function slugify(s) { return s.toLowerCase().replace(/[àáâã]/g,'a').replace(/[èéê]/g,'e').replace(/[ìíî]/g,'i').replace(/[òóô]/g,'o').replace(/[ùúû]/g,'u').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,''); }
function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t=setTimeout(()=>fn(...a),ms); }; }
function sanitize(s) { const d=document.createElement('div'); d.textContent=s; return d.innerHTML; }
const CAT_BADGE = { politica:'b-blue',economia:'b-green',mondo:'b-purple',sport:'b-orange',cultura:'b-red',tecnologia:'b-blue',salute:'b-red',scienze:'b-purple',ambiente:'b-green',italia:'b-red',blog:'b-orange' };
const CAT_EMOJI = { politica:'🏛',economia:'💹',mondo:'🌍',sport:'⚽',cultura:'🎭',tecnologia:'💻',salute:'🏥',scienze:'🔬',ambiente:'🌿',italia:'🇮🇹',blog:'✍️' };
function catBadge(cat) { return `<span class="badge ${CAT_BADGE[cat]||'b-gray'}">${CAT_EMOJI[cat]||'📰'} ${cat||'news'}</span>`; }

/* ── Page log ── */
async function logView() {
  await SB.post('page_views', { page: location.pathname }).catch(()=>{});
}

/* ── Boot ── */
document.addEventListener('DOMContentLoaded', () => {
  Theme.init();
  Nav.init();
  Reveal.init();
  setTimeout(() => {
    const l = document.getElementById('page-loader');
    if (l) { l.classList.add('hide'); setTimeout(()=>l.remove(),600); }
  }, 500);
  logView();
});
