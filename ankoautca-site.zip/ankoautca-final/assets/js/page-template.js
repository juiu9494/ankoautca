/* Shared page template builder - used by category pages */
function buildCategoryPage(config){
  document.title=`${config.title} — ANKOAUTCA`;
  document.getElementById('cat-hero-icon').textContent=config.icon;
  document.getElementById('cat-hero-title').textContent=config.title;
  document.getElementById('cat-hero-desc').textContent=config.desc;
  document.getElementById('cat-hero-style').style.background=config.gradient;
  loadCategoryArticles(config.cat,config.supaFilter);
}
async function loadCategoryArticles(cat,filter){
  const grid=document.getElementById('cat-grid');
  const feat=document.getElementById('cat-featured');
  showSkeleton(grid,6);
  let arts=null;
  try{
    const q=filter||`category=eq.${cat}`;
    const d=await SB.get('articles',`select=*&${q}&published=eq.true&order=created_at.desc&limit=20`);
    if(d&&d.length>0)arts=d;
  }catch{}
  if(!arts)arts=STATIC_NEWS.filter(a=>cat==='all'||a.category===cat);
  if(!arts.length)arts=STATIC_NEWS;

  // Featured
  const f=arts[0];
  if(feat&&f){
    feat.style.cssText=`background:linear-gradient(135deg,hsl(${f.hue||220},60%,20%),hsl(${(f.hue||220)+40},50%,36%));min-height:280px;border-radius:var(--r-l);position:relative;overflow:hidden;cursor:pointer;margin-bottom:20px`;
    feat.innerHTML=`<div style="position:absolute;inset:0;background:linear-gradient(0deg,rgba(0,0,0,.85) 0%,transparent 55%)"></div>
      <div style="position:absolute;bottom:0;left:0;right:0;padding:clamp(14px,3vw,24px);color:#fff">
        <div style="margin-bottom:8px">${catBadge(f.category)}</div>
        <h2 style="font-family:var(--serif);font-size:clamp(20px,3vw,32px);font-weight:900;line-height:1.2;margin-bottom:8px">${sanitize(f.title)}</h2>
        <p style="font-size:14px;opacity:.8;margin-bottom:10px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">${sanitize(f.excerpt||'')}</p>
        <div style="font-size:12px;opacity:.65;display:flex;gap:8px;flex-wrap:wrap"><span>✍️ ${f.author}</span><span>·</span><span>${timeAgo(f.created_at)}</span><span>·</span><span>👁 ${fNum(f.views)}</span></div>
      </div>`;
    feat.onclick=()=>location.href='article.html?id='+f.id;
  }

  // Grid
  grid.innerHTML=arts.slice(1).map(a=>`
    <div class="nc card-hover" onclick="location.href='article.html?id=${a.id}'">
      <div class="nc-img"><div class="art-ph" style="--h:${a.hue||0};height:100%"></div><div class="nc-badge">${catBadge(a.category)}</div></div>
      <div class="nc-body">
        <h3 class="nc-title truncate-2">${sanitize(a.title)}</h3>
        <p class="nc-exc truncate-2">${sanitize(a.excerpt||'')}</p>
        <div class="nc-meta"><span class="nc-author">✍️ ${a.author}</span><span>📖 ${a.reading_time||3} min</span></div>
      </div>
    </div>`).join('');
  Reveal.init();
}
function showSkeleton(el,n){
  el.innerHTML=Array(n).fill(0).map(()=>`
    <div class="card" style="overflow:hidden">
      <div class="sk sk-img" style="height:160px"></div>
      <div style="padding:14px"><div class="sk sk-title"></div><div class="sk sk-line"></div><div class="sk sk-line" style="width:70%"></div></div>
    </div>`).join('');
}
