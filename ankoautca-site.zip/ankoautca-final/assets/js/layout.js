/* ================================================================
   ANKOAUTCA — LAYOUT.JS  (navbar + footer injection)
   ================================================================ */
const Layout = {
  navHTML(root) {
    return `
<div id="page-loader"><div class="pl-logo"><span>A</span>NKOAUTCA</div><div class="pl-bar"><div class="pl-fill"></div></div></div>
<div id="toast-wrap"></div>

<nav class="navbar">
  <a href="${root}index.html" class="nav-logo"><span>A</span>NKOAUTCA <sub>News</sub></a>

  <div class="nav-links">
    <a href="${root}index.html"         class="nav-link">🏠 Home</a>
    <a href="${root}pages/news.html"    class="nav-link">📰 News</a>
    <a href="${root}pages/blog.html"    class="nav-link">✍️ Blog</a>
    <a href="${root}pages/politique.html" class="nav-link">🏛 Politica</a>
    <a href="${root}pages/economie.html"  class="nav-link">💹 Economia</a>
    <a href="${root}pages/sport.html"   class="nav-link">⚽ Sport</a>
    <a href="${root}pages/tech.html"    class="nav-link">💻 Tech</a>
    <a href="${root}pages/meteo.html"   class="nav-link">🌤 Meteo</a>
    <a href="${root}pages/contact.html" class="nav-link">✉️ Contatti</a>
  </div>

  <div class="nav-actions">
    <a href="${root}pages/recherche.html" class="nav-btn" title="Cerca">🔍</a>
    <button class="nav-btn" data-theme-btn title="Tema"><span data-ti>🌙</span></button>
    <div class="nav-sep"></div>
    <a href="${root}pages/login.html"     class="nav-cta btn-pill" data-auth-hide>Accedi</a>
    <a href="${root}pages/dashboard.html" class="nav-cta btn-pill" data-auth-show style="display:none">⚙️ Admin</a>
  </div>

  <div class="hamburger" id="hamburger"><span></span><span></span><span></span></div>
</nav>

<div class="mobile-nav" id="mobile-nav">
  <a href="${root}index.html"            class="mob-link">🏠 Home</a>
  <a href="${root}pages/news.html"       class="mob-link">📰 Ultime Notizie</a>
  <a href="${root}pages/blog.html"       class="mob-link">✍️ Blog</a>
  <a href="${root}pages/politique.html"  class="mob-link">🏛 Politica</a>
  <a href="${root}pages/economie.html"   class="mob-link">💹 Economia</a>
  <a href="${root}pages/sport.html"      class="mob-link">⚽ Sport</a>
  <a href="${root}pages/tech.html"       class="mob-link">💻 Tecnologia</a>
  <a href="${root}pages/culture.html"    class="mob-link">🎭 Cultura</a>
  <a href="${root}pages/science.html"    class="mob-link">🔬 Scienze</a>
  <a href="${root}pages/meteo.html"      class="mob-link">🌤 Meteo</a>
  <a href="${root}pages/contact.html"    class="mob-link">✉️ Contatti</a>
  <div class="mob-sep"></div>
  <a href="${root}pages/recherche.html"  class="mob-link">🔍 Cerca</a>
  <a href="${root}pages/login.html"      class="mob-link" data-auth-hide>🔐 Accedi</a>
  <a href="${root}pages/dashboard.html"  class="mob-link" data-auth-show style="display:none">⚙️ Admin</a>
  <a href="${root}pages/newsletter.html" class="mob-link">📧 Newsletter</a>
  <div class="mob-sep"></div>
  <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 14px">
    <span style="font-size:13px;color:var(--t2)">Tema</span>
    <button class="theme-toggle" data-theme-btn></button>
  </div>
</div>`;
  },

  footerHTML(root) {
    return `
<footer class="footer">
  <div class="wrap">
    <div class="footer-grid">
      <div>
        <div class="footer-logo"><span>A</span>NKOAUTCA</div>
        <p class="footer-desc">Il portale italiano di notizie, attualità e approfondimento. Informazione libera, indipendente e rigorosa — ogni giorno dall'Italia e dal mondo.</p>
        <a href="mailto:gastroboostmarketingdigital@gmail.com" style="display:inline-flex;align-items:center;gap:8px;background:var(--red);color:#fff;padding:9px 18px;border-radius:var(--r-f);font-size:13px;font-weight:700;transition:background .2s" onmouseover="this.style.background='#8B0000'" onmouseout="this.style.background='var(--red)'">🤝 Collabora con noi</a>
        <div class="footer-social">
          <a class="fsoc" href="#" title="Facebook">f</a>
          <a class="fsoc" href="#" title="X">𝕏</a>
          <a class="fsoc" href="#" title="Instagram">📷</a>
          <a class="fsoc" href="#" title="YouTube">▶</a>
          <a class="fsoc" href="#" title="Telegram">✈</a>
        </div>
      </div>
      <div>
        <div class="footer-col-title">Sezioni</div>
        <div class="footer-links">
          <a href="${root}pages/news.html">📰 Ultime Notizie</a>
          <a href="${root}pages/politique.html">🏛 Politica</a>
          <a href="${root}pages/economie.html">💹 Economia</a>
          <a href="${root}pages/sport.html">⚽ Sport</a>
          <a href="${root}pages/tech.html">💻 Tecnologia</a>
          <a href="${root}pages/culture.html">🎭 Cultura</a>
          <a href="${root}pages/science.html">🔬 Scienze</a>
          <a href="${root}pages/meteo.html">🌤 Meteo</a>
        </div>
      </div>
      <div>
        <div class="footer-col-title">Altro</div>
        <div class="footer-links">
          <a href="${root}pages/blog.html">✍️ Blog</a>
          <a href="${root}pages/video.html">🎬 Video</a>
          <a href="${root}pages/podcast.html">🎙 Podcast</a>
          <a href="${root}pages/newsletter.html">📧 Newsletter</a>
          <a href="${root}pages/recherche.html">🔍 Cerca</a>
          <a href="${root}pages/contact.html">✉️ Contatti</a>
          <a href="${root}pages/about.html">ℹ️ Chi siamo</a>
        </div>
      </div>
      <div>
        <div class="footer-col-title">Legale</div>
        <div class="footer-links">
          <a href="#">Privacy Policy</a>
          <a href="#">Cookie Policy</a>
          <a href="#">Termini di Servizio</a>
          <a href="#">Note Legali</a>
          <a href="${root}pages/login.html">Admin</a>
        </div>
        <div style="margin-top:18px">
          <div class="footer-col-title">Newsletter</div>
          <form onsubmit="footerNL(event)" style="display:flex;gap:7px;margin-top:8px;flex-wrap:wrap">
            <input type="email" placeholder="La tua email" required style="flex:1;min-width:140px;padding:8px 12px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);border-radius:var(--r-m);font-size:12px;color:#fff;outline:none">
            <button type="submit" style="padding:8px 14px;background:var(--red);color:#fff;border:none;border-radius:var(--r-m);font-size:12px;font-weight:700;cursor:pointer;white-space:nowrap">→</button>
          </form>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <span>© 2025 ANKOAUTCA — Tutti i diritti riservati · P.IVA 00000000000</span>
      <div class="fb-links">
        <a href="#">Privacy</a><a href="#">Cookie</a><a href="#">Note Legali</a>
      </div>
    </div>
  </div>
</footer>`;
  },

  inject() {
    const root = location.pathname.includes('/pages/') ? '../' : './';
    const nSlot = document.getElementById('nav-slot');
    const fSlot = document.getElementById('footer-slot');
    if (nSlot)  nSlot.outerHTML  = this.navHTML(root);
    if (fSlot)  fSlot.outerHTML  = this.footerHTML(root);
  }
};

function footerNL(e) {
  e.preventDefault();
  Toast.show('Iscrizione confermata!','Benvenuto nella newsletter ANKOAUTCA.','success');
  e.target.reset();
}

document.addEventListener('DOMContentLoaded', () => Layout.inject());
