/* ================================================================
   ANKOAUTCA — SUPABASE CONFIG
   URL:  https://rmugngceojbarttctsoo.supabase.co
   ================================================================ */

const SUPA_URL = 'https://rmugngceojbarttctsoo.supabase.co';
// Anon key — remplace par ta vraie clé depuis Settings > API dans Supabase Dashboard
const SUPA_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJtdWduZ2Nlb2piYXJ0dGN0c29vIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDAwMDAwMDAsImV4cCI6MjA1MDAwMDAwMH0.REPLACE_WITH_REAL_KEY';

/* ── REST client léger (sans SDK) ── */
const SB = {
  h() {
    return {
      'Content-Type':  'application/json',
      'apikey':        SUPA_KEY,
      'Authorization': 'Bearer ' + SUPA_KEY
    };
  },
  async get(table, qs = '') {
    try {
      const url = SUPA_URL + '/rest/v1/' + table + (qs ? '?' + qs : '');
      const r = await fetch(url, { headers: this.h() });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return await r.json();
    } catch(e) { console.warn('[SB.get]', table, e.message); return null; }
  },
  async post(table, body) {
    try {
      const r = await fetch(SUPA_URL + '/rest/v1/' + table, {
        method: 'POST',
        headers: { ...this.h(), 'Prefer': 'return=representation' },
        body: JSON.stringify(body)
      });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return await r.json();
    } catch(e) { console.warn('[SB.post]', table, e.message); return null; }
  },
  async patch(table, filter, body) {
    try {
      const r = await fetch(SUPA_URL + '/rest/v1/' + table + '?' + filter, {
        method: 'PATCH',
        headers: { ...this.h(), 'Prefer': 'return=representation' },
        body: JSON.stringify(body)
      });
      return r.ok;
    } catch(e) { console.warn('[SB.patch]', e.message); return false; }
  },
  async del(table, filter) {
    try {
      const r = await fetch(SUPA_URL + '/rest/v1/' + table + '?' + filter, {
        method: 'DELETE', headers: this.h()
      });
      return r.ok;
    } catch(e) { return false; }
  }
};

/* ── STATIC FALLBACK (si Supabase vide ou inaccessible) ── */
const STATIC_NEWS = [
  {id:1,category:'politica',title:"Il Parlamento approva la riforma costituzionale con 318 voti a favore",excerpt:"Una storica riforma che cambia il volto dello Stato italiano dopo decenni di dibattiti parlamentari e consultazioni popolari in tutto il paese.",author:"Giulia Marchetti",created_at:"2025-05-13T08:00:00Z",views:48230,reading_time:4,featured:true,hue:220,tags:["governo","riforma","parlamento"]},
  {id:2,category:'economia',title:"Borsa di Milano ai massimi: FTSE MIB sfonda quota 40.000 punti",excerpt:"La corsa dei mercati europei trainata dal settore energetico e bancario. Gli analisti restano ottimisti per il secondo semestre.",author:"Marco Ferretti",created_at:"2025-05-13T09:15:00Z",views:31450,reading_time:3,featured:true,hue:140,tags:["borsa","mercati","economia"]},
  {id:3,category:'sport',title:"Azzurri ai Mondiali 2026: l'Italia batte la Grecia 3-0 con una prestazione dominante",excerpt:"Doppietta di Scamacca e rete di Barella regalano la qualificazione con due turni di anticipo. Festa in tutto il paese.",author:"Roberto Conti",created_at:"2025-05-13T10:00:00Z",views:44200,reading_time:2,featured:true,hue:30,tags:["calcio","mondiale","nazionale"]},
  {id:4,category:'tecnologia',title:"OpenAI lancia GPT-5: ragionamento a livello umano nelle scienze",excerpt:"Il nuovo modello supera i benchmark in matematica, codice e ragionamento complesso. Disponibile gratuitamente per tutti gli utenti.",author:"Elena Russo",created_at:"2025-05-13T11:00:00Z",views:19800,reading_time:5,featured:false,hue:270,tags:["AI","OpenAI","tech"]},
  {id:5,category:'salute',title:"Alzheimer: scoperto biomarcatore che anticipa la diagnosi di 10 anni",excerpt:"Ricercatori italiani protagonisti di una svolta scientifica mondiale pubblicata su Nature Medicine. Un passo cruciale per la prevenzione.",author:"Federica Rizzo",created_at:"2025-05-12T14:00:00Z",views:17200,reading_time:4,featured:false,hue:330,tags:["alzheimer","salute","ricerca"]},
  {id:6,category:'mondo',title:"Gaza: accordo di tregua per 45 giorni mediato da Qatar e USA",excerpt:"Dopo settimane di negoziati le parti raggiungono un'intesa con scambi di ostaggi e apertura di corridoi umanitari.",author:"Andrea Lombardo",created_at:"2025-05-12T16:00:00Z",views:38900,reading_time:5,featured:false,hue:50,tags:["gaza","guerra","diplomazia"]},
  {id:7,category:'ambiente',title:"Siccità record in Sicilia: governo dichiara lo stato di emergenza idrica",excerpt:"Le riserve idriche dell'isola sono al minimo storico. Misure straordinarie per oltre 2 milioni di cittadini.",author:"Luca Esposito",created_at:"2025-05-12T18:00:00Z",views:14500,reading_time:3,featured:false,hue:160,tags:["siccità","sicilia","ambiente"]},
  {id:8,category:'cultura',title:"Paolo Sorrentino vince la Palma d'Oro a Cannes con 'La Grazia'",excerpt:"Il regista napoletano torna al vertice del cinema mondiale con un'opera personale, commovente e visivamente straordinaria.",author:"Valentina Serra",created_at:"2025-05-11T20:00:00Z",views:9700,reading_time:3,featured:false,hue:300,tags:["cinema","cannes","sorrentino"]},
  {id:9,category:'scienze',title:"Rover ESA atterra con successo sul Polo Sud della Luna: missione storica",excerpt:"La prima missione lunare europea tocca suolo selenico dopo sei anni di preparazione. Obiettivo: trovare ghiaccio d'acqua.",author:"Chiara Fontana",created_at:"2025-05-11T12:00:00Z",views:21400,reading_time:4,featured:false,hue:190,tags:["luna","ESA","spazio"]},
  {id:10,category:'economia',title:"FIAT annuncia 5.000 nuove assunzioni in Italia: investimento da 3 miliardi",excerpt:"Il piano industriale 2025-2030 punta sui veicoli elettrici e l'automazione avanzata degli stabilimenti nazionali.",author:"Paolo Gentili",created_at:"2025-05-11T09:00:00Z",views:12300,reading_time:3,featured:false,hue:100,tags:["FIAT","lavoro","auto"]},
  {id:11,category:'politica',title:"Crisi di governo: il Premier annuncia le dimissioni al Quirinale",excerpt:"Dopo la rottura con il principale alleato di coalizione, il Presidente del Consiglio rimette il mandato nelle mani del Capo dello Stato.",author:"Marco Ferretti",created_at:"2025-05-10T17:00:00Z",views:55600,reading_time:5,featured:false,hue:210,tags:["governo","crisi","premier"]},
  {id:12,category:'sport',title:"Formula 1 Monaco: Leclerc vince il GP di casa davanti ai tifosi",excerpt:"Il pilota monegasco della Ferrari porta a casa la vittoria più emozionante della sua carriera nel circuito di casa.",author:"Roberto Conti",created_at:"2025-05-10T15:00:00Z",views:44200,reading_time:3,featured:false,hue:40,tags:["F1","ferrari","monaco"]},
  {id:13,category:'tecnologia',title:"Meta lancia gli occhiali AR con ologrammi: rivoluzione nella realtà aumentata",excerpt:"Il nuovo visore di Meta supera Apple Vision Pro in leggerezza e autonomia. Disponibile in Europa da settembre 2025.",author:"Elena Russo",created_at:"2025-05-10T10:00:00Z",views:16800,reading_time:4,featured:false,hue:250,tags:["AR","Meta","realtà aumentata"]},
  {id:14,category:'mondo',title:"Nato: summit straordinario a Bruxelles per rafforzare la difesa orientale",excerpt:"I 32 paesi membri approvano un piano da 400 miliardi per i prossimi cinque anni. Focus sul confine con la Russia.",author:"Andrea Lombardo",created_at:"2025-05-10T08:00:00Z",views:29100,reading_time:5,featured:false,hue:60,tags:["NATO","difesa","europa"]},
  {id:15,category:'salute',title:"Vaccino anti-cancro al pancreas: risultati positivi in fase 2",excerpt:"I risultati presentati all'ASCO mostrano una riduzione del 60% della progressione tumorale. Speranza concreta per migliaia di pazienti.",author:"Federica Rizzo",created_at:"2025-05-09T14:00:00Z",views:18900,reading_time:5,featured:false,hue:320,tags:["cancro","vaccino","oncologia"]},
];

const STATIC_BLOGS = [
  {id:1,title:"Perché l'Italia deve investire di più nella ricerca scientifica",excerpt:"Un'analisi approfondita del gap tra investimenti pubblici italiani ed europei nella ricerca e sviluppo tecnologico. I dati e le proposte concrete.",author:"Prof. Alberto Mancini",avatar:"AM",created_at:"2025-05-12T10:00:00Z",views:8400,read_time:6,hue:200,tags:["ricerca","università","politica"],content:"Il problema degli investimenti italiani nella ricerca è strutturale. L'Italia spende l'1.3% del PIL in R&S, ben al di sotto della media europea del 2.2% e del target del 3% fissato dalla Strategia di Lisbona..."},
  {id:2,title:"Il futuro del giornalismo nell'era dell'intelligenza artificiale",excerpt:"Come l'IA sta trasformando la produzione e il consumo delle notizie. Sfide, opportunità e rischi concreti per il settore dell'informazione.",author:"Elena Russo",avatar:"ER",created_at:"2025-05-11T14:00:00Z",views:6700,read_time:5,hue:260,tags:["AI","giornalismo","media"],content:"L'intelligenza artificiale non sostituirà il giornalismo, ma trasformerà profondamente il modo in cui le notizie vengono prodotte, distribuite e consumate..."},
  {id:3,title:"La cucina italiana nel mondo: un'eccellenza da proteggere e valorizzare",excerpt:"Dal pesto alla carbonara: il soft power della gastronomia italiana tra tutele IGP, imitazioni globali e nuove sfide del mercato.",author:"Valentina Serra",avatar:"VS",created_at:"2025-05-10T11:00:00Z",views:5200,read_time:4,hue:20,tags:["cucina","cultura","turismo"],content:"La cucina italiana è molto più di un insieme di ricette. È un patrimonio culturale, un'identità collettiva, uno strumento di diplomazia gastronomica..."},
  {id:4,title:"Giovani e politica: l'astensionismo è un segnale che non possiamo ignorare",excerpt:"L'analisi del calo della partecipazione elettorale tra i 18-35 anni e le possibili soluzioni per riportare i giovani alle urne.",author:"Dott.ssa Carla Benedetti",avatar:"CB",created_at:"2025-05-09T09:00:00Z",views:4800,read_time:7,hue:240,tags:["giovani","politica","democrazia"],content:"Alle ultime elezioni politiche, il 42% degli italiani tra i 18 e i 35 anni non ha votato. Un dato allarmante che impone una riflessione profonda..."},
  {id:5,title:"Smart working nel 2025: bilancio di cinque anni dall'esperimento pandemico",excerpt:"Chi lavora da casa, con quali risultati e a quale costo. Un'analisi dati del fenomeno che ha trasformato il mondo del lavoro italiano.",author:"Paolo Gentili",avatar:"PG",created_at:"2025-05-08T16:00:00Z",views:7100,read_time:5,hue:130,tags:["lavoro","smart working","economia"],content:"Cinque anni dopo l'esplosione del lavoro da remoto durante la pandemia, è tempo di fare un bilancio onesto..."},
  {id:6,title:"Il Mediterraneo come frontiera: immigrazione e geopolitica nel 2025",excerpt:"Un'analisi delle rotte migratorie nel 2025 e delle politiche europee di gestione dei flussi. Dati, tendenze e prospettive.",author:"Andrea Lombardo",avatar:"AL",created_at:"2025-05-07T08:00:00Z",views:9300,read_time:8,hue:180,tags:["immigrazione","mediterraneo","EU"],content:"Il Mediterraneo rimane la frontiera più trafficata e pericolosa del mondo. Nel 2024, oltre 180.000 persone hanno attraversato il mare verso l'Europa..."},
];
